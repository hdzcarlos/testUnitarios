
class Persona {

	String nombre;
	
}
