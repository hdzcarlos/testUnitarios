package red.dominio;

public interface Alarma {
	
	void activa();

}
