package red.dominio;

public class AlarmaSonora implements Alarma {

	@Override
	public void activa() {
		System.out.println("buuuuu buuuuuuu buuuuuuuu");
	}

}
